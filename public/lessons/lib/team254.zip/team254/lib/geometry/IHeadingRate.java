package com.team254.lib.geometry;

public interface IHeadingRate<S> {
    public double getHeadingRate();
}
