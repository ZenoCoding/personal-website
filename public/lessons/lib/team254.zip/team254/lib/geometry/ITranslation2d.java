package com.team254.lib.geometry;

public interface ITranslation2d<S> extends State<S> {
    Translation2d getTranslation();
}
